import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from sdk.models import MoveCommand, Pose, RobotStatus
from services.robot_service import robot_service
from services.tour_service import tour_service

router = APIRouter(prefix="/api/robot", tags=["robot"])


class ManualModeRequest(BaseModel):
    enabled: bool


@router.get("/status", response_model=RobotStatus)
async def get_status() -> RobotStatus:
    return robot_service.get_status()


@router.get("/pose", response_model=Pose)
async def get_pose() -> Pose:
    return robot_service.get_pose()


@router.post("/move")
async def move(command: MoveCommand) -> dict:
    await robot_service.move(command)
    return {"ok": True}


@router.post("/stop")
async def stop() -> dict:
    await robot_service.stop()
    return {"ok": True}


@router.post("/emergency-stop")
async def emergency_stop() -> dict:
    await tour_service.halt()
    await robot_service.emergency_stop()
    return {"ok": True}


@router.post("/release-emergency-stop")
async def release_emergency_stop() -> dict:
    await robot_service.release_emergency_stop()
    return {"ok": True}


@router.post("/mode/manual")
async def set_manual_mode(request: ManualModeRequest) -> dict:
    await robot_service.set_manual_mode(request.enabled)
    return {"ok": True, "manual": request.enabled}


@router.post("/relocalize")
async def relocalize() -> dict:
    status = robot_service.get_status()
    if not status.connected:
        raise HTTPException(
            status_code=503,
            detail="Robot non connecté — vérifiez le Wi‑Fi et la connexion rosbridge",
        )
    launched = await robot_service.global_localization()
    if not launched:
        raise HTTPException(
            status_code=503,
            detail="Impossible de lancer la relocalisation sur le robot",
        )
    status = robot_service.get_status()
    return {
        "ok": True,
        "message": "Relocalisation lancée — le robot va tourner sur lui-même",
        "localization_percent": status.localization_percent,
        "localization_label": status.localization_label,
    }
